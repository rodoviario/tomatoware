#define RARVER_MAJOR     5
#define RARVER_MINOR    20
#define RARVER_BETA      3
#define RARVER_DAY       3
#define RARVER_MONTH    11
#define RARVER_YEAR   2014
