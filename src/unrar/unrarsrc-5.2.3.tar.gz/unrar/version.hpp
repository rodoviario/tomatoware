#define RARVER_MAJOR     5
#define RARVER_MINOR    20
#define RARVER_BETA      0
#define RARVER_DAY       2
#define RARVER_MONTH    12
#define RARVER_YEAR   2014
