objc_EXPORT struct sarray* 
objc_get_uninstalled_dtable(void);
