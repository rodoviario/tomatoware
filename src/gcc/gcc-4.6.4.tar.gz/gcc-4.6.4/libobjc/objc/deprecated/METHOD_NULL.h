/* For functions which return Method_t */
#define METHOD_NULL	(Method_t)0
