void *
objc_valloc(size_t size);
