/* Incredibly obsolete.  */
typedef char *STR;  /* String alias */
