typedef struct objc_class *MetaClass;
